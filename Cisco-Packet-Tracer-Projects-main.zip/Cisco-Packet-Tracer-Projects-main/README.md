# Cisco Packet Tracer Projects
All Networking Related Practicals in Cisco Packet Tracer

## About Cisco Packet Tracer
Packet Tracer is a tool which used to implement the knowledge of networking that we have gained and to prepare some popular exams like CCNA. This is a virtual environment that intimate a live Networking Simulation.

Download the Cisco Packet Tracer Latest Version [here](https://www.netacad.com/courses/packet-tracer)

Download all the Previous Versions of Cisco Packet Tracer [here](https://www.computernetworkingnotes.com/ccna-study-guide/download-packet-tracer-for-windows-and-linux.html)

## About This Repository

  This repository contains all the cisco packet tracer essential as well as additional labs which will be very helpful in studying and understanding Cisco Networking Topics. I am a Network Engineer and I have been studying networking since 2020 and I have learnt tones of new concepts related to this field and they are very interesting topics to study.

Hope this repository helps you to clear your theoretical concepts by applying your knowledge in simulated lab environment.
