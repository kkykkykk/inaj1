# Here you will find all the Basic Cisco Packet Tracer Projects which will cover basic networking topics like
__All These Projects will done in Command Line Interface Mode__
- Router Configurations
- Switch Configurations
- Implementing Local Area Networks
- Connecting two or more Local Area Networks
- Static Routing (OSPF) Open Shortest Path First
- Dynamic Routing (RIP) Routing Information Protocol
- Implementing OSI Model
- Router - Switch Connection
- DHCP Server Configurations
- FTP Server Configurations

Updating...
